#Wesley Louden 11/9/23
#This program will read the CSV file "births.csv" 
#and print out which month of the year had the largest number of births. 
#This will loop year by year from 2008-2014.
import csv
#Function to find most births 
def largest_births_month(filename, year):
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        births_by_month = {}
        for row in reader:
            if int(row['year']) == year:
                month = row['month']
                if month in births_by_month:
                    births_by_month[month] += int(row['births'])
                else:
                    births_by_month[month] = int(row['births'])
        max_births_month = max(births_by_month, key= births_by_month.get)
        print(f"For {year} the month with the highest births was {max_births_month} with {births_by_month[max_births_month]} total births.")
      
#Loop for every year
for year in range(2008, 2015):
    largest_births_month('births.csv', year)